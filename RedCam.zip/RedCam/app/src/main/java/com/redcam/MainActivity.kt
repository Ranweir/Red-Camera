package com.redcam

import android.Manifest
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.params.TonemapCurve
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Size
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.camera2.interop.Camera2CameraControl
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.camera2.interop.CaptureRequestOptions
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ExtendableBuilder
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

val Red = Color(0xFFE53935)

// Frosted glass (replaces liquid glass): translucent dark fill + soft border
fun Modifier.frosted(r: Dp = 24.dp) = this
    .clip(RoundedCornerShape(r))
    .background(Color(0x66222222))
    .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(r))

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("redcam", Context.MODE_PRIVATE)
    var grid by mutableStateOf(sp.getBoolean("grid", false))
    var vibrant by mutableStateOf(sp.getBoolean("vibrant", true))
    var boost by mutableStateOf(sp.getInt("boost", 1))   // 0 off, 1 +0.7EV, 2 +1.3EV
    var maxQ by mutableStateOf(sp.getBoolean("maxq", true))
    var vq by mutableStateOf(sp.getInt("vq", 1))          // 0 HD, 1 FHD, 2 4K
    fun save() {
        sp.edit().putBoolean("grid", grid).putBoolean("vibrant", vibrant).putInt("boost", boost)
            .putBoolean("maxq", maxQ).putInt("vq", vq).apply()
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { Root() }
    }
}

@Composable
fun Root() {
    val perms = remember {
        buildList<String> {
            add(Manifest.permission.CAMERA)
            add(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 33) {
                add(Manifest.permission.READ_MEDIA_IMAGES)
                add(Manifest.permission.READ_MEDIA_VIDEO)
            } else add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }.toTypedArray()
    }
    var ok by remember { mutableStateOf(false) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        ok = it[Manifest.permission.CAMERA] == true
    }
    LaunchedEffect(Unit) { launcher.launch(perms) }
    Box(Modifier.fillMaxSize().background(Color.Black)) { if (ok) CameraScreen() }
}

@OptIn(ExperimentalCamera2Interop::class)
fun <T> quality(b: ExtendableBuilder<T>) {
    Camera2Interop.Extender(b).apply {
        setCaptureRequestOption(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
        setCaptureRequestOption(CaptureRequest.NOISE_REDUCTION_MODE, CaptureRequest.NOISE_REDUCTION_MODE_HIGH_QUALITY)
        setCaptureRequestOption(CaptureRequest.EDGE_MODE, CaptureRequest.EDGE_MODE_HIGH_QUALITY)
        setCaptureRequestOption(CaptureRequest.COLOR_CORRECTION_ABERRATION_MODE, CaptureRequest.COLOR_CORRECTION_ABERRATION_MODE_HIGH_QUALITY)
    }
}

@OptIn(ExperimentalCamera2Interop::class)
fun brighten(cam: Camera, p: Prefs) {
    val st = cam.cameraInfo.exposureState
    if (st.isExposureCompensationSupported) {
        val ev = listOf(0f, 0.7f, 1.3f)[p.boost]
        val idx = (ev / st.exposureCompensationStep.toFloat()).roundToInt()
            .coerceIn(st.exposureCompensationRange.lower, st.exposureCompensationRange.upper)
        cam.cameraControl.setExposureCompensationIndex(idx)
    }
    val modes = Camera2CameraInfo.from(cam.cameraInfo)
        .getCameraCharacteristic(CameraCharacteristics.TONEMAP_AVAILABLE_TONE_MAP_MODES)
    val ctl = Camera2CameraControl.from(cam.cameraControl)
    if (p.vibrant && modes?.contains(CaptureRequest.TONEMAP_MODE_CONTRAST_CURVE) == true) {
        val c = floatArrayOf(0f, 0f, 0.25f, 0.30f, 0.5f, 0.58f, 0.75f, 0.83f, 1f, 1f)
        ctl.setCaptureRequestOptions(
            CaptureRequestOptions.Builder()
                .setCaptureRequestOption(CaptureRequest.TONEMAP_MODE, CaptureRequest.TONEMAP_MODE_CONTRAST_CURVE)
                .setCaptureRequestOption(CaptureRequest.TONEMAP_CURVE, TonemapCurve(c, c, c))
                .build()
        )
    } else ctl.setCaptureRequestOptions(CaptureRequestOptions.Builder().build())
}

fun latestMedia(ctx: Context): Bitmap? = runCatching {
    val f = MediaStore.Files.FileColumns.MEDIA_TYPE
    ctx.contentResolver.query(
        MediaStore.Files.getContentUri("external"),
        arrayOf(MediaStore.Files.FileColumns._ID, f), "$f IN (1,3)", null,
        "${MediaStore.Files.FileColumns.DATE_ADDED} DESC"
    )?.use { c ->
        if (c.moveToFirst()) {
            val u = ContentUris.withAppendedId(
                if (c.getInt(1) == 1) MediaStore.Images.Media.EXTERNAL_CONTENT_URI else MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                c.getLong(0))
            ctx.contentResolver.loadThumbnail(u, Size(256, 256), null)
        } else null
    }
}.getOrNull()

// Opens the phone's default gallery app
fun openGallery(ctx: Context) {
    try {
        ctx.startActivity(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_GALLERY)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        try { ctx.startActivity(Intent(Intent.ACTION_VIEW).setType("image/*").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (e2: Exception) {}
    }
}

fun fmt(z: Float) = if (abs(z - z.roundToInt()) < 0.05f) z.roundToInt().toString() else "%.1f".format(z)

@Composable
fun CameraScreen() {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()
    val exec = remember { ContextCompat.getMainExecutor(ctx) }
    val p = remember { Prefs(ctx) }
    val pv = remember { PreviewView(ctx).apply { scaleType = PreviewView.ScaleType.FILL_CENTER } }
    val rPx = ctx.resources.displayMetrics.widthPixels * 0.6f
    var front by remember { mutableStateOf(false) }
    var video by remember { mutableStateOf(false) }
    var flash by remember { mutableIntStateOf(0) }
    var timer by remember { mutableIntStateOf(0) }
    var count by remember { mutableIntStateOf(0) }
    var zoom by remember { mutableFloatStateOf(1f) }
    var dial by remember { mutableStateOf(false) }
    var tick by remember { mutableIntStateOf(0) }
    var settings by remember { mutableStateOf(false) }
    var cam by remember { mutableStateOf<Camera?>(null) }
    var ic by remember { mutableStateOf<ImageCapture?>(null) }
    var vc by remember { mutableStateOf<VideoCapture<Recorder>?>(null) }
    var rec by remember { mutableStateOf<Recording?>(null) }
    var focusPt by remember { mutableStateOf<Offset?>(null) }
    var thumb by remember { mutableStateOf<Bitmap?>(null) }

    fun setZoom(z: Float) {
        val zs = cam?.cameraInfo?.zoomState?.value
        zoom = z.coerceIn(zs?.minZoomRatio ?: 1f, min(zs?.maxZoomRatio ?: 1f, 10f))
        cam?.cameraControl?.setZoomRatio(zoom)
    }
    fun dragZoom(dx: Float, r: Float) {
        setZoom(zoom * exp(-(dx / r) * 57.2958f / 24f))
        dial = true; tick++
    }
    fun loadThumb(u: Uri?) {
        if (u == null) return
        scope.launch(Dispatchers.IO) {
            val b = runCatching { ctx.contentResolver.loadThumbnail(u, Size(256, 256), null) }.getOrNull()
            if (b != null) thumb = b
        }
    }
    fun focus(o: Offset) {
        cam?.cameraControl?.startFocusAndMetering(
            FocusMeteringAction.Builder(pv.meteringPointFactory.createPoint(o.x, o.y),
                FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE)
                .setAutoCancelDuration(3, TimeUnit.SECONDS).build())
        focusPt = o
    }
    fun capture() {
        val cv = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "RED_${System.currentTimeMillis()}")
            put(MediaStore.MediaColumns.MIME_TYPE, if (video) "video/mp4" else "image/jpeg")
            put(MediaStore.MediaColumns.RELATIVE_PATH, if (video) "Movies/RedCam" else "Pictures/RedCam")
        }
        if (!video) {
            ic?.flashMode = when (flash) { 0 -> ImageCapture.FLASH_MODE_OFF; 1 -> ImageCapture.FLASH_MODE_AUTO; else -> ImageCapture.FLASH_MODE_ON }
            ic?.takePicture(
                ImageCapture.OutputFileOptions.Builder(ctx.contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv).build(),
                exec, object : ImageCapture.OnImageSavedCallback {
                    override fun onImageSaved(r: ImageCapture.OutputFileResults) { loadThumb(r.savedUri) }
                    override fun onError(e: ImageCaptureException) {}
                })
        } else if (rec != null) {
            rec?.stop()
        } else {
            val o = MediaStoreOutputOptions.Builder(ctx.contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI).setContentValues(cv).build()
            rec = vc?.output?.prepareRecording(ctx, o)?.withAudioEnabled()?.start(exec) { ev ->
                if (ev is VideoRecordEvent.Finalize) { rec = null; loadThumb(ev.outputResults.outputUri) }
            }
        }
    }
    fun shoot() {
        scope.launch {
            if (!video && timer > 0) { for (i in timer downTo 1) { count = i; delay(1000) }; count = 0 }
            capture()
        }
    }

    LaunchedEffect(Unit) { thumb = withContext(Dispatchers.IO) { latestMedia(ctx) } }
    LaunchedEffect(tick) { if (dial) { delay(1500); dial = false } }
    LaunchedEffect(focusPt) { if (focusPt != null) { delay(1200); focusPt = null } }
    LaunchedEffect(front, video, p.maxQ, p.vq) {
        val prov = ProcessCameraProvider.getInstance(ctx).get()
        val pre = Preview.Builder().also { quality(it) }.build().also { it.setSurfaceProvider(pv.surfaceProvider) }
        val sel = if (front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
        prov.unbindAll()
        cam = if (!video) {
            val i = ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                .setJpegQuality(if (p.maxQ) 100 else 90).also { quality(it) }.build()
            ic = i
            prov.bindToLifecycle(owner, sel, pre, i)
        } else {
            val q = listOf(Quality.HD, Quality.FHD, Quality.UHD)[p.vq]
            val v = VideoCapture.withOutput(Recorder.Builder()
                .setQualitySelector(QualitySelector.from(q, FallbackStrategy.lowerQualityOrHigherThan(q))).build())
            vc = v
            prov.bindToLifecycle(owner, sel, pre, v)
        }
        zoom = 1f
    }
    LaunchedEffect(cam, p.boost, p.vibrant) { cam?.let { brighten(it, p) } }

    Box(Modifier.fillMaxSize()) {
        AndroidView({ pv }, Modifier.fillMaxSize())
        if (p.grid) Canvas(Modifier.fillMaxSize()) {
            for (i in 1..2) {
                val x = size.width * i / 3; val y = size.height * i / 3
                drawLine(Color(0x66FFFFFF), Offset(x, 0f), Offset(x, size.height), 1.5f)
                drawLine(Color(0x66FFFFFF), Offset(0f, y), Offset(size.width, y), 1.5f)
            }
        }
        // pinch-zoom + tap-to-focus layer
        Box(Modifier.fillMaxSize()
            .pointerInput(Unit) { detectTransformGestures { _, _, z, _ -> if (z != 1f) { setZoom(zoom * z); dial = true; tick++ } } }
            .pointerInput(Unit) { detectTapGestures { focus(it) } })
        focusPt?.let { o ->
            Box(Modifier.offset { IntOffset((o.x - 36.dp.toPx()).roundToInt(), (o.y - 36.dp.toPx()).roundToInt()) }
                .size(72.dp).border(2.dp, Red, CircleShape))
        }

        // TOP bar
        Row(Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(top = 8.dp, start = 16.dp, end = 16.dp)
            .fillMaxWidth().frosted(28.dp).padding(horizontal = 22.dp, vertical = 12.dp),
            Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Text(listOf("⚡ off", "⚡ auto", "⚡ on")[flash], color = if (flash == 0) Color.White else Red, fontSize = 15.sp,
                modifier = Modifier.clickable { flash = (flash + 1) % 3 })
            Text("⏱ " + if (timer == 0) "off" else "${timer}s", color = if (timer == 0) Color.White else Red, fontSize = 15.sp,
                modifier = Modifier.clickable { timer = when (timer) { 0 -> 3; 3 -> 10; else -> 0 } })
            Text("▦ grid", color = if (p.grid) Red else Color.White, fontSize = 15.sp,
                modifier = Modifier.clickable { p.grid = !p.grid; p.save() })
            Text("⚙", color = Color.White, fontSize = 22.sp, modifier = Modifier.clickable { settings = true })
        }
        if (count > 0) Text("$count", color = Color.White, fontSize = 96.sp, modifier = Modifier.align(Alignment.Center))

        if (dial) ZoomDial(zoom) { dx, r -> dragZoom(dx, r) }

        // BOTTOM
        Column(Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 12.dp).fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.height(44.dp).alpha(if (dial) 0f else 1f), contentAlignment = Alignment.Center) {
                val pills = listOf(1f, 2f, 3f)
                val act = pills.indexOfLast { it <= zoom + 0.02f }.coerceAtLeast(0)
                Row(Modifier.pointerInput(Unit) {
                    detectHorizontalDragGestures(onDragStart = { dial = true; tick++ }) { c, dx -> c.consume(); dragZoom(dx, rPx) }
                }, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    pills.forEachIndexed { i, v ->
                        Box(Modifier.size(40.dp).clip(CircleShape)
                            .background(if (i == act) Color(0x66808080) else Color.Transparent)
                            .clickable { setZoom(v) }, contentAlignment = Alignment.Center) {
                            Text(if (i == act) fmt(zoom) + "x" else fmt(v), color = if (i == act) Red else Color.White, fontSize = 15.sp)
                        }
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Box(Modifier.size(76.dp).border(4.dp, if (rec != null) Red else Color(0xAAFFFFFF), CircleShape)
                .padding(6.dp).clip(CircleShape).background(if (video) Red else Color.White).clickable { shoot() })
            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth().padding(horizontal = 22.dp), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Box(Modifier.size(56.dp).clip(CircleShape).background(Color.White).clickable { openGallery(ctx) }) {
                    thumb?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
                }
                Row(Modifier.frosted(28.dp).padding(4.dp)) {
                    listOf("VIDEO" to true, "PHOTO" to false).forEach { (t, v) ->
                        val sel = video == v
                        Text(t, color = if (sel) Red else Color.White, fontSize = 16.sp,
                            modifier = Modifier
                                .then(if (sel) Modifier.border(1.5.dp, Color(0xAAFFFFFF), RoundedCornerShape(24.dp)) else Modifier)
                                .clickable { if (rec == null) video = v }
                                .padding(horizontal = 20.dp, vertical = 10.dp))
                    }
                }
                Box(Modifier.size(56.dp).frosted(28.dp).clickable { if (rec == null) front = !front }, contentAlignment = Alignment.Center) {
                    Canvas(Modifier.size(26.dp)) {
                        drawArc(color = Color.White, startAngle = 30f, sweepAngle = 300f, useCenter = false,
                            style = Stroke(width = 5f, cap = StrokeCap.Round))
                    }
                }
            }
        }
        if (settings) SettingsScreen(p) { settings = false }
    }
}

@Composable
fun BoxScope.ZoomDial(zoom: Float, onDrag: (Float, Float) -> Unit) {
    BoxWithConstraints(Modifier.align(Alignment.BottomCenter).fillMaxWidth().fillMaxHeight(0.47f)
        .pointerInput(Unit) { detectHorizontalDragGestures { c, dx -> c.consume(); onDrag(dx, size.width * 0.6f) } }) {
        val w = constraints.maxWidth.toFloat()
        val r = w * 0.6f
        Canvas(Modifier.fillMaxSize()) {
            val c = Offset(size.width / 2, r)
            drawCircle(Color(0xCC1C1C1E), r, c)
            drawCircle(Color(0x33FFFFFF), r, c, style = Stroke(2f))
            for (k in 5..100) {
                val a = -90f + ln((k / 10f) / zoom) * 24f
                if (abs(a + 90f) > 75f) continue
                val major = k % 10 == 0 || k == 5
                val rad = Math.toRadians(a.toDouble())
                val d = Offset(cos(rad).toFloat(), sin(rad).toFloat())
                drawLine(if (major) Color.White else Color(0x88FFFFFF), c + d * r, c + d * (r - if (major) 34f else 16f), 2.5f)
            }
            drawLine(Red, Offset(c.x, 0f), Offset(c.x, 56f), 7f, StrokeCap.Round)
        }
        listOf(Triple(0.5f, "0,5", "13MM"), Triple(1f, "1x", "24MM"), Triple(2f, "2", ""),
            Triple(3f, "3", "77MM"), Triple(5f, "5", ""), Triple(10f, "10", "")).forEach { (z, t, mm) ->
            val ang = -90f + ln(z / zoom) * 24f
            if (abs(ang + 90f) < 40f) {
                val rad = Math.toRadians(ang.toDouble())
                val lr = r - w * 0.115f
                val x = w / 2 + lr * cos(rad).toFloat()
                val y = r + lr * sin(rad).toFloat()
                val on = abs(ln(z / zoom)) < 0.04f
                Column(Modifier.offset { IntOffset((x - 30.dp.toPx()).roundToInt(), (y - 24.dp.toPx()).roundToInt()) }.size(60.dp, 48.dp),
                    horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(t, color = if (on) Red else Color.White, fontSize = 17.sp)
                    if (mm.isNotEmpty()) Text(mm, color = if (on) Red else Color(0x99FFFFFF), fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(p: Prefs, onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    Column(Modifier.fillMaxSize().background(Color(0xF2101010)).statusBarsPadding().navigationBarsPadding()
        .padding(20.dp).verticalScroll(rememberScrollState())) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("←", color = Color.White, fontSize = 28.sp, modifier = Modifier.clickable { onBack() }.padding(end = 16.dp))
            Text("Settings", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(24.dp))
        SwitchRow("Grid lines", p.grid) { p.grid = it; p.save() }
        SwitchRow("Vibrant colours", p.vibrant) { p.vibrant = it; p.save() }
        Seg("Brightness boost", listOf("Off", "Normal", "High"), p.boost) { p.boost = it; p.save() }
        Seg("Photo quality", listOf("Standard", "Max"), if (p.maxQ) 1 else 0) { p.maxQ = it == 1; p.save() }
        Seg("Video quality", listOf("HD", "FHD", "4K"), p.vq) { p.vq = it; p.save() }
    }
}

@Composable
fun SwitchRow(t: String, v: Boolean, on: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), Arrangement.SpaceBetween, Alignment.CenterVertically) {
        Text(t, color = Color.White, fontSize = 17.sp)
        Switch(v, on, colors = SwitchDefaults.colors(checkedTrackColor = Red, checkedThumbColor = Color.White))
    }
}

@Composable
fun Seg(t: String, opts: List<String>, sel: Int, on: (Int) -> Unit) {
    Column(Modifier.padding(vertical = 10.dp)) {
        Text(t, color = Color.White, fontSize = 17.sp)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.frosted(20.dp).padding(4.dp)) {
            opts.forEachIndexed { i, o ->
                Text(o, color = Color.White, fontSize = 15.sp,
                    modifier = Modifier.clip(RoundedCornerShape(16.dp))
                        .background(if (i == sel) Red else Color.Transparent)
                        .clickable { on(i) }.padding(horizontal = 16.dp, vertical = 8.dp))
            }
        }
    }
}
