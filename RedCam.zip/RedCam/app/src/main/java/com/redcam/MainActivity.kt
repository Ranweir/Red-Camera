package com.redcam

import android.Manifest
import android.content.ContentValues
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.params.TonemapCurve
import android.os.Bundle
import android.provider.MediaStore
import android.view.MotionEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.camera2.interop.*
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.*
import androidx.camera.view.PreviewView
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt

val Red = Color(0xFFE53935)

// Frosted glass (replaces liquid glass): translucent dark fill + soft border
fun Modifier.frosted(r: Dp = 24.dp) = this
    .clip(RoundedCornerShape(r))
    .background(Color(0x66222222))
    .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(r))

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { Root() }
    }
}

@Composable
fun Root() {
    val perms = arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
    var ok by remember { mutableStateOf(false) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        ok = it[Manifest.permission.CAMERA] == true
    }
    LaunchedEffect(Unit) { launcher.launch(perms) }
    Box(Modifier.fillMaxSize().background(Color.Black)) { if (ok) CameraScreen() }
}

@OptIn(ExperimentalCamera2Interop::class)
fun <T> quality(b: ExtendableBuilder<T>) {
    Camera2Interop.Extender(b).apply {
        setCaptureRequestOption(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
        setCaptureRequestOption(CaptureRequest.NOISE_REDUCTION_MODE, CaptureRequest.NOISE_REDUCTION_MODE_HIGH_QUALITY)
        setCaptureRequestOption(CaptureRequest.EDGE_MODE, CaptureRequest.EDGE_MODE_HIGH_QUALITY)
        setCaptureRequestOption(CaptureRequest.COLOR_CORRECTION_ABERRATION_MODE, CaptureRequest.COLOR_CORRECTION_ABERRATION_MODE_HIGH_QUALITY)
    }
}

@OptIn(ExperimentalCamera2Interop::class)
fun brighten(cam: Camera) {
    // +0.7 EV: affects viewfinder and photo equally
    val st = cam.cameraInfo.exposureState
    if (st.isExposureCompensationSupported) {
        val idx = (0.7f / st.exposureCompensationStep.toFloat()).roundToInt()
            .coerceIn(st.exposureCompensationRange.lower, st.exposureCompensationRange.upper)
        cam.cameraControl.setExposureCompensationIndex(idx)
    }
    // Vibrant S-curve tonemap, only where the device supports it
    val modes = Camera2CameraInfo.from(cam.cameraInfo)
        .getCameraCharacteristic(CameraCharacteristics.TONEMAP_AVAILABLE_TONE_MAP_MODES)
    if (modes?.contains(CaptureRequest.TONEMAP_MODE_CONTRAST_CURVE) == true) {
        val c = floatArrayOf(0f, 0f, 0.25f, 0.30f, 0.5f, 0.58f, 0.75f, 0.83f, 1f, 1f)
        Camera2CameraControl.from(cam.cameraControl).setCaptureRequestOptions(
            CaptureRequestOptions.Builder()
                .setCaptureRequestOption(CaptureRequest.TONEMAP_MODE, CaptureRequest.TONEMAP_MODE_CONTRAST_CURVE)
                .setCaptureRequestOption(CaptureRequest.TONEMAP_CURVE, TonemapCurve(c, c, c))
                .build()
        )
    }
}

@Composable
fun CameraScreen() {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val exec = remember { ContextCompat.getMainExecutor(ctx) }
    val pv = remember { PreviewView(ctx).apply { scaleType = PreviewView.ScaleType.FILL_CENTER } }
    var front by remember { mutableStateOf(false) }
    var video by remember { mutableStateOf(false) }
    var flash by remember { mutableStateOf(false) }
    var zoom by remember { mutableStateOf(1f) }
    var cam by remember { mutableStateOf<Camera?>(null) }
    var ic by remember { mutableStateOf<ImageCapture?>(null) }
    var vc by remember { mutableStateOf<VideoCapture<Recorder>?>(null) }
    var rec by remember { mutableStateOf<Recording?>(null) }
    var focusPt by remember { mutableStateOf<Pair<Float, Float>?>(null) }

    LaunchedEffect(front, video) {
        val p = ProcessCameraProvider.getInstance(ctx).get()
        val pre = Preview.Builder().also { quality(it) }.build().also { it.setSurfaceProvider(pv.surfaceProvider) }
        val sel = if (front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
        p.unbindAll()
        cam = if (!video) {
            val i = ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                .setJpegQuality(100).also { quality(it) }.build()
            ic = i
            p.bindToLifecycle(owner, sel, pre, i)
        } else {
            val v = VideoCapture.withOutput(Recorder.Builder().setQualitySelector(QualitySelector.from(Quality.HIGHEST)).build())
            vc = v
            p.bindToLifecycle(owner, sel, pre, v)
        }
        cam?.let { brighten(it); zoom = 1f }
    }
    LaunchedEffect(focusPt) { if (focusPt != null) { delay(1200); focusPt = null } }

    fun shoot() {
        val cv = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "RED_${System.currentTimeMillis()}")
            put(MediaStore.MediaColumns.MIME_TYPE, if (video) "video/mp4" else "image/jpeg")
            put(MediaStore.MediaColumns.RELATIVE_PATH, if (video) "Movies/RedCam" else "Pictures/RedCam")
        }
        if (!video) {
            ic?.flashMode = if (flash) ImageCapture.FLASH_MODE_ON else ImageCapture.FLASH_MODE_OFF
            ic?.takePicture(
                ImageCapture.OutputFileOptions.Builder(ctx.contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv).build(),
                exec, object : ImageCapture.OnImageSavedCallback {
                    override fun onImageSaved(r: ImageCapture.OutputFileResults) {}
                    override fun onError(e: ImageCaptureException) {}
                })
        } else if (rec != null) { rec?.stop(); rec = null }
        else {
            val o = MediaStoreOutputOptions.Builder(ctx.contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI).setContentValues(cv).build()
            rec = vc?.output?.prepareRecording(ctx, o)?.withAudioEnabled()?.start(exec) {}
        }
    }

    fun openGallery() {
        val i = try {
            Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_GALLERY)
        } catch (e: Exception) {
            Intent(Intent.ACTION_VIEW).setType("image/*")
        }
        try { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (e: Exception) { ctx.startActivity(Intent(Intent.ACTION_VIEW).setType("image/*").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }

    Box(Modifier.fillMaxSize()) {
        AndroidView({ pv.also { v ->
            v.setOnTouchListener { _, e ->
                if (e.action == MotionEvent.ACTION_UP) {
                    cam?.cameraControl?.startFocusAndMetering(
                        FocusMeteringAction.Builder(v.meteringPointFactory.createPoint(e.x, e.y),
                            FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE)
                            .setAutoCancelDuration(3, TimeUnit.SECONDS).build())
                    focusPt = e.x to e.y
                }
                true
            }
        } }, Modifier.fillMaxSize())

        focusPt?.let { (x, y) ->
            Box(Modifier.offset { androidx.compose.ui.unit.IntOffset(x.toInt() - 36.dp.roundToPx(), y.toInt() - 36.dp.roundToPx()) }
                .size(72.dp).border(2.dp, Red, CircleShape))
        }

        // TOP: ColorOS 17 style capsule bar
        Row(Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(top = 8.dp, start = 16.dp, end = 16.dp)
            .fillMaxWidth().frosted(28.dp).padding(horizontal = 20.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("⚡", color = if (flash) Red else Color.White, fontSize = 20.sp, modifier = Modifier.clickable { flash = !flash })
            Text("AI", color = Color.White, fontSize = 16.sp)
            Text("HDR", color = Red, fontSize = 16.sp)
            Text("⚙", color = Color.White, fontSize = 20.sp)
        }

        // BOTTOM
        Column(Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 16.dp).fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally) {
            Row(Modifier.frosted(20.dp).padding(horizontal = 8.dp, vertical = 4.dp)) {
                listOf(0.5f, 1f, 2f).forEach { z ->
                    val real = z.coerceIn(cam?.cameraInfo?.zoomState?.value?.minZoomRatio ?: 1f, cam?.cameraInfo?.zoomState?.value?.maxZoomRatio ?: 1f)
                    Text(if (z == 1f) "1x" else "${z}x", color = if (zoom == real) Red else Color.White, fontSize = 15.sp,
                        modifier = Modifier.clickable { zoom = real; cam?.cameraControl?.setZoomRatio(real) }.padding(horizontal = 12.dp, vertical = 6.dp))
                }
            }
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(28.dp)) {
                Text("VIDEO", color = if (video) Red else Color.White, modifier = Modifier.clickable { video = true })
                Text("PHOTO", color = if (!video) Red else Color.White, modifier = Modifier.clickable { video = false })
            }
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth().padding(horizontal = 36.dp), horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(52.dp).frosted(14.dp).clickable { openGallery() }, contentAlignment = Alignment.Center) { Text("🖼", fontSize = 22.sp) }
                Box(Modifier.size(76.dp).border(4.dp, Color.White, CircleShape).padding(7.dp)
                    .clip(CircleShape).background(if (rec != null) Red else Color.White).clickable { shoot() })
                Box(Modifier.size(52.dp).frosted(26.dp).clickable { front = !front }, contentAlignment = Alignment.Center) { Text("⟲", color = Color.White, fontSize = 24.sp) }
            }
        }
    }
}
